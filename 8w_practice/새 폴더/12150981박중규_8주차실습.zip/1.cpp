﻿#include <iostream>
#include <ctime>


using namespace std;

int main()
{
     //quiz 1
    
    char str1[5] = "1234";
    char str2[5] = "5678";
    
    cout << "char1 = " << str1 << ", char2 = " << str2 << endl;
    
    cout << "char1 + char2 = " << str1 << str2;


}
